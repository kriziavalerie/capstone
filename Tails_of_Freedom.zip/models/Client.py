from app_factory import db


class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(30), nullable=False)
    last_name = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, name="unique_email_constraint")
    username = db.Column(db.String(20), unique=False, nullable=False)
    password = db.Column(db.String(60), nullable=True)
    age = db.Column(db.Integer)
    address = db.Column(db.String(100))
    contact_number = db.Column(db.String(20))
    date_applied = db.Column(db.Date)
    email_address = db.Column(db.String(100))
    application_status = db.Column(db.String(20))  # Pending, Approved, Declined
    reason_to_qualify = db.Column(db.Text)
    employment_status = db.Column(db.String(20))
    number_of_pets = db.Column(db.Integer)
    animal_id = db.Column(db.Integer, db.ForeignKey('animal.id', name='fk_client_animal_id'))
    animals = db.relationship('ClientAnimal', back_populates='client')