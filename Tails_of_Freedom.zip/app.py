
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
from sqlalchemy.exc import IntegrityError
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired
from flask import request
from werkzeug.utils import secure_filename
from datetime import datetime
import os
import app_factory
from routes import admin_routes, animal_health_routes, animal_owner_routes, animal_routes, animal_story_routes, auth_routes, client_routes, animal_details_routes, google_oauth_routes
from flask_oauthlib.client import OAuth
from app_factory import db, bcrypt
from models.Admin import Admin


app = app_factory.app
oauth = OAuth(app)
app.register_blueprint(admin_routes.admin_blueprint)
app.register_blueprint(animal_health_routes.animal_health_blueprint)
app.register_blueprint(animal_owner_routes.animal_owner_blueprint)
app.register_blueprint(animal_routes.animal_blueprint)
app.register_blueprint(animal_story_routes.animal_story_blueprint)
app.register_blueprint(auth_routes.auth_blueprint)
app.register_blueprint(client_routes.client_blueprint)
app.register_blueprint(animal_details_routes.animal_details_blueprint)
app.register_blueprint(google_oauth_routes.google_oauth_blueprint, url_prefix='/google')


# # Create the admin user
# admin_password = 'tails_of_freedom'
# hashed_password = bcrypt.generate_password_hash(admin_password).decode('utf-8')
# admin = Admin(
#     first_name='Admin',
#     last_name='User',
#     email='admin@example.com',
#     username='admin',
#     password=hashed_password
# )

# # Add the admin user to the database
# with app.app_context():
#     db.create_all()
#     db.session.add(admin)
#     db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)
 
